<template>
  <div>
    <input type="text" v-model="postBody" @change="postPost()"/>
    <ul v-if="errors && errors.length">
      <li v-for="(error,index) in errors" :key="index">
        {{error.message}}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      postBody: '',
      errors: []
    }
  },

  // Gửi request lên server khi mà postPost() được gọi
  methods: {
    postPost() {
      axios.post('http://192.168.1.11:5001/test', {
        email: this.postBody
      })
      .then(response => {
        console.log(response);
      })
      .catch(e => {
        this.errors.push(e)
      })
    }
  }
}
</script>