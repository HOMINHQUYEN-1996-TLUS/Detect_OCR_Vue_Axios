<template lang="">
  <div>
    <input type="file" @change="previewFiles" multiple />
    <input type="text" name="" id="" v-model="msg">
    <button @click="sendData">SEND</button>
  </div>
</template>
<script>
import axios from 'axios';
export default {
  
  data(){
    return {
      msg: '',
      fileData: ''
    }
  },
  methods: {
    // getMessage(){
    //   const path = 'http://192.168.1.11:5000/test';
    //   //const path = 'https://hoctaptlus.xyz/test'
    //   axios.get(path).then((res) => {
    //     console.log(res);
    //     this.msg = res.data['status'];
    //   }).catch((error) => {
    //     console.error(error);
    //   })
    // },
    previewFiles(event) {
      this.fileData = event.target.files[0]
      console.log(this.fileData);
    },
    sendData(){
      const path = 'http://192.168.1.11:5001/test';
      axios.post(path, {
        email: this.msg
      }).then(function (res) {
        console.log(res.data);
      }). catch(function (error){
        console.log('ERROR: '+error);
      })
    }
  },
  created(){
    // this.getMessage();
  }
}
</script>
<style lang="">
  
</style>