import Vue from 'vue';
import Router from 'vue-router';
import Ping from '../components/PingData.vue';
import Test from '../components/TestRequest.vue'

Vue.use(Router);

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/ping',
      name: 'Ping',
      component: Ping,
    },
    {
      path: '/test',
      name: 'Test',
      component: Test
    }
  ],
});